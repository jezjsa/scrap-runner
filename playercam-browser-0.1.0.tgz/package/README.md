# `@playercam/browser`

The PlayerCam browser SDK supplies exact player positions while the PlayerCam
Chrome extension records a game. It performs no recording or network upload by
itself.

## Install the developer preview

Download the SDK tarball from the PlayerCam site, then install it into a Vite or
other modern JavaScript project:

```bash
npm install ./playercam-browser-0.1.0.tgz
```

## Canvas game

```ts
import { playerCam } from "@playercam/browser";

playerCam.track("player", {
  canvas: document.querySelector("canvas")!,
  getBounds: () => ({
    // Return visible Canvas coordinates, after applying the game's camera.
    x: player.x - camera.x,
    y: player.y - camera.y,
    width: player.width,
    height: player.height,
  }),
});
```

`x` and `y` are the top-left corner by default. Canvas backing-store pixels are
normalized automatically, including Canvas size, CSS scaling and device-pixel
ratio differences.

If the game already stores normalized centre coordinates:

```ts
playerCam.track("player", {
  coordinateSpace: "normalized",
  origin: "center",
  getBounds: () => player.normalizedBounds,
});
```

## DOM game

```ts
playerCam.track("player", {
  canvas,
  coordinateSpace: "client",
  getBounds: () => {
    const rect = playerElement.getBoundingClientRect();
    return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
  },
});
```

## Optional game events

Events are timestamped against the active recording and stored with its
telemetry:

```ts
playerCam.event("enemy_defeated", { enemy: "training_bot" });
playerCam.event("special_move");
playerCam.event("level_complete", { score });
```

The SDK samples only while the PlayerCam extension is recording. Video and
telemetry remain local to the browser until the user explicitly keeps a take.
